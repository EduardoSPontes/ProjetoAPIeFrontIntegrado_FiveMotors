﻿namespace FiveMotors.ViewModels
{
    public class FaleComVendedorView
    {
        public Guid FaleComVendedorId { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
        public string Assunto { get; set; }
    }
}
